C4 diagnostic bundle c44MJohvNzaepCGNYW1sLjBXLaSRRhWNkC6U4WV6wsTjKc2EgbXatCbgfSFjCrUjR3rZnbm1HpjbR854djWLPWE1nn

What this holds: snapshots of the scheduler's input and decisions,
the build, and the farm's shape. Every name (shows, shots, jobs, units,
people, pools, sites, links, classes) is a keyed pseudonym that only
this farm can map back; every time is relative to its snapshot, with
no date or zone; every amount of money is scaled by a secret factor
that is not in this bundle; sizes keep two significant figures.

What this never holds: names, paths, file contents, prompts, messages,
logs, environment, parameters, images, raw C4 IDs of the work, dates,
or the farm's key. Every entry but this one is listed in manifest.c4m
with its size and C4 ID, and the bundle's ID is the manifest's.

Snapshots: 10, of which 10 replay to the farm's own decisions.
Key epoch: 1

Replay: hack/sim -bundle <this file> -replay decide
